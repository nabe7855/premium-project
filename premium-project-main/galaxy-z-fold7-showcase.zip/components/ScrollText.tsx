import React, { useState, useEffect, useRef } from 'react';

/**
 * スクロール連動でテキストがフェードインするセクション。
 * - 画面中央に固定され、スクロールに応じてメッセージが表示されます。
 * - Intersection Observer APIを使用して、要素の表示状態を監視します。
 */
const ScrollText: React.FC = () => {
    const [isVisible, setIsVisible] = useState(false);
    const ref = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const observer = new IntersectionObserver(
            ([entry]) => {
                setIsVisible(entry.isIntersecting);
            },
            { threshold: 0.5 }
        );

        if (ref.current) {
            observer.observe(ref.current);
        }

        return () => {
            if (ref.current) {
                observer.unobserve(ref.current);
            }
        };
    }, []);

    return (
        <section ref={ref} className="h-[200vh] relative">
            <div className="sticky top-0 h-screen bg-black flex items-center justify-center text-white overflow-hidden">
                <h2 className={`transition-opacity duration-1000 text-5xl md:text-7xl font-bold text-center leading-tight ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
                    Ultraスペックを折りたた<br/>んだスマートフォンで。
                </h2>
            </div>
        </section>
    );
};

export default ScrollText;
