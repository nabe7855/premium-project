import React from 'react';

/**
 * 製品の薄さとデザインを強調するセクション。
 * - 大きな見出しと説明文で、製品の物理的な特徴を伝えます。
 */
const ThinnessSection: React.FC = () => (
    <section className="h-[80vh] bg-indigo-50 flex flex-col justify-center items-start text-black relative overflow-hidden">
        <img src="https://picsum.photos/id/101/1920/1080" alt="Phone in hand" className="absolute z-0 w-full h-full object-cover opacity-20"/>
        <div className="max-w-screen-xl mx-auto px-4 z-10">
            <h2 className="text-5xl md:text-7xl font-black tracking-tighter">圧倒的な薄さ。</h2>
            <p className="mt-4 max-w-2xl text-lg">
            折りたたんだ状態でも開いた状態でも、期待を越える新次元のGalaxy Z Fold7。カバー画面は21:9の比率に進化し、さらに薄型化しました。握り心地や入力のしやすさもこれまで以上に向上し、快適に作業が行えます。
            </p>
        </div>
    </section>
);

export default ThinnessSection;
