import React from 'react';

/**
 * メディアからのレビューや評価を引用して表示するセクション。
 * - 主要なテックメディアのロゴと引用文を並べて表示します。
 */
const MediaReviews: React.FC = () => {
    const reviews = [
        { logo: 'CNET', quote: '「薄くて軽量なのに、カメラにも妥協なし」', date: '2025年7月掲載' },
        { logo: 'PhoneArena', quote: '「超薄型で軽量、そしてカバー画面が広くなった、いまでで最も妥協のないGalaxy Fold」', date: '2025年7月掲載' },
        { logo: 'TechRadar', quote: '「新たなOne UI 9を搭載したこのデバイスは、折りたたみスマホ体験のために最適化された、インテリジェントでマルチモーダルなAIエージェントを統合している」', date: '2025年7月掲載' },
    ];
    return (
        <section className="bg-white py-24">
            <div className="max-w-screen-xl mx-auto px-4 grid md:grid-cols-3 gap-12 text-center">
                {reviews.map((review, index) => (
                    <div key={index} className="flex flex-col items-center">
                        <p className="text-gray-500 text-sm">オンラインメディア</p>
                        <h3 className="text-3xl font-bold my-4">{review.logo}</h3>
                        <p className="text-gray-700 flex-grow">"{review.quote}"</p>
                        <p className="text-gray-500 text-sm mt-6">{review.date}</p>
                    </div>
                ))}
            </div>
        </section>
    );
};

export default MediaReviews;
