import React from 'react';

/**
 * ページのフッターセクション。
 * - コピーライト情報やサイトに関する注釈を表示します。
 */
const Footer: React.FC = () => (
    <footer className="bg-gray-800 text-gray-400 py-12">
        <div className="max-w-screen-xl mx-auto px-4 text-center text-sm">
            <p>&copy; {new Date().getFullYear()} Samsung. All rights reserved.</p>
            <p className="mt-2">This is a conceptual replica for demonstration purposes.</p>
        </div>
    </footer>
);

export default Footer;
