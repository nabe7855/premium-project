import React, { useState, useEffect, useRef } from 'react';
import type { Feature } from '../types';
import { PauseIcon } from './icons';

const featureData: Feature[] = [
    { title: "Galaxy Z Fold史上最薄、最軽量¹", subtitle: "驚きの携帯性", description: "再設計により、かつてない薄さと軽さを実現しました。デバイスの内側と外側の両面に広がる大画面が、職人技息づくシームレスな新しい世界を映し出します。", imageUrl: "https://images.unsplash.com/photo-1598495494482-172d254d911a?q=80&w=2592&auto=format&fit=crop" },
    { title: "超高精細。超クリアな写真", subtitle: "約2億画素 広角カメラ", description: "驚異的なディテールを捉える200MPカメラ。昼夜を問わず、あらゆる瞬間を鮮明に記録します。", imageUrl: "https://images.unsplash.com/photo-1516048015947-89335d16246b?q=80&w=2524&auto=format&fit=crop" },
    { title: "最強のプロセッサ", subtitle: "Samsung Galaxy用にカスタマイズ", description: "Galaxy Z Fold6よりも約38%高速な処理性能。ゲームもマルチタスクも、かつてないほどスムーズに。", imageUrl: "https://images.unsplash.com/photo-1597733336794-12d05021d510?q=80&w=2592&auto=format&fit=crop" },
    { title: "一日中使える高効率バッテリー²³⁴", subtitle: "バッテリー容量 約4,400 mAh", description: "最適化されたバッテリーマネジメントで、朝から晩まであなたの活動をサポートし続けます。", imageUrl: "https://images.unsplash.com/photo-1544228865-9d3b8789e5ae?q=80&w=2592&auto=format&fit=crop" },
    { title: "次世代のGalaxy AI対応", subtitle: "大画面デバイス", description: "折りたたみスマホ体験のために最適化された、インテリジェントでマルチモーダルなAIエージェントを統合しています。", imageUrl: "https://images.unsplash.com/photo-1534140723323-2b2a3d02213b?q=80&w=2592&auto=format&fit=crop" },
];

/**
 * 製品の主要機能をスクロールアニメーションで見せるセクション。
 * - ユーザーがスクロールすると、カードが3D空間を移動するように見えます。
 * - 各カードには機能のタイトル、画像、説明が含まれています。
 * - スクロール位置に応じて、アクティブなカードが中央に表示されます。
 */
const FeatureShowcase: React.FC = () => {
    const [scrollProgress, setScrollProgress] = useState(0);
    const containerRef = useRef<HTMLDivElement>(null);
    const scrollableHeightRef = useRef(0);

    useEffect(() => {
        const container = containerRef.current;
        if (!container) return;

        const ro = new ResizeObserver(() => {
            scrollableHeightRef.current = container.offsetHeight - window.innerHeight;
        });
        ro.observe(container);
        
        scrollableHeightRef.current = container.offsetHeight - window.innerHeight;

        const handleScroll = () => {
            if (scrollableHeightRef.current > 0) {
                const rect = container.getBoundingClientRect();
                const progress = -rect.top / scrollableHeightRef.current;
                setScrollProgress(Math.max(0, Math.min(1, progress)));
            } else {
                setScrollProgress(0);
            }
        };

        window.addEventListener('scroll', handleScroll, { passive: true });
        handleScroll();

        return () => {
            ro.disconnect();
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    const totalCards = featureData.length;
    const currentCardProgress = scrollProgress * (totalCards - 1);
    const activeIndex = Math.round(currentCardProgress);

    return (
        <section className="bg-white">
            <div ref={containerRef} style={{ height: `${totalCards * 120}vh` }} className="relative">
                <div className="sticky top-0 h-screen flex flex-col items-center justify-start pt-24 pb-12 overflow-hidden">
                    <div className="text-center mb-10 z-20 px-4">
                        <h2 className="text-4xl md:text-6xl font-bold text-black">まったく新しいFoldシリーズが、<br/>ここから始まる</h2>
                    </div>

                    <div className="relative w-full h-[75vh] flex items-center justify-center [transform-style:preserve-3d]" style={{ perspective: '2500px' }}>
                        {featureData.map((feature, i) => {
                            const distance = i - currentCardProgress;
                            
                            if (distance > 1.5 || distance < -1.5) {
                                return null;
                            }
                            
                            let translateY, translateZ, scale, opacity;

                            const Y_OFFSET_VH = 40;
                            const Z_OFFSET_FRONT_PX = 600;
                            const Z_OFFSET_BACK_PX = -800;
                            const SCALE_IN = 0.85;
                            const SCALE_OUT = 0.6;

                            const ANIMATION_RANGE = 0.8; 

                            if (distance >= 0) {
                                // Card is at the center or coming from the front (bottom)
                                const progress = Math.max(0, Math.min(1, (ANIMATION_RANGE - distance) / ANIMATION_RANGE));
                                translateY = (1 - progress) * Y_OFFSET_VH;
                                translateZ = (1 - progress) * Z_OFFSET_FRONT_PX;
                                scale = SCALE_IN + progress * (1 - SCALE_IN);
                                opacity = 1;
                            } else {
                                // Card is moving to the back (top)
                                const progress = Math.max(0, Math.min(1, (ANIMATION_RANGE + distance) / ANIMATION_RANGE));
                                translateY = distance * Y_OFFSET_VH;
                                translateZ = -distance * Z_OFFSET_BACK_PX;
                                scale = SCALE_OUT + progress * (1 - SCALE_OUT);
                                opacity = progress;
                            }
                            
                            const zIndex = 100 - Math.abs(Math.round(distance * 10));
                            
                            const contentOpacity = Math.max(0, 1 - Math.abs(distance) * 1.5);

                            return (
                                <div
                                    key={i}
                                    className="absolute w-[90vw] max-w-4xl h-[70vh] bg-black rounded-3xl shadow-2xl overflow-hidden"
                                    style={{
                                        transform: `translateY(${translateY}vh) translateZ(${translateZ}px) scale(${scale})`,
                                        transformOrigin: 'center center',
                                        opacity,
                                        zIndex,
                                    }}
                                >
                                    <img
                                        src={feature.imageUrl}
                                        alt={feature.title}
                                        className="absolute inset-0 w-full h-full object-cover"
                                    />
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div>
                                    <div className="relative z-10 p-8 text-white h-full flex flex-col justify-between" style={{ opacity: contentOpacity }}>
                                        <div>
                                            <h3 className="text-4xl font-bold mt-1">{feature.title}</h3>
                                            <p className="text-xl font-semibold text-gray-200">{feature.subtitle}</p>
                                        </div>
                                         <div className="flex justify-end items-center">
                                             <button aria-label="Play/Pause" className="w-16 h-16 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-colors">
                                                <PauseIcon className="w-8 h-8"/>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                    <div className="absolute top-1/2 right-10 -translate-y-1/2 flex flex-col space-y-4 z-30">
                         {featureData.map((_, index) => (
                            <div key={index} className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${activeIndex === index ? 'bg-black scale-150' : 'bg-gray-400'}`}></div>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default FeatureShowcase;
