import React, { useState, useEffect } from 'react';
import { SearchIcon, CartIcon, UserIcon, ChevronDownIcon } from './icons';

/**
 * ページのヘッダーセクション。
 * スクロールに応じて表示が変化するナビゲーションバーを含みます。
 * - 上部には主要なナビゲーションリンクとアイコンが表示されます。
 * - スクロールすると、製品名と購入ボタンを含むサブヘッダーが表示されます。
 */
const Header: React.FC = () => {
    const [isScrolled, setIsScrolled] = useState(false);

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 50);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md transition-shadow duration-300">
            <div className="max-w-screen-xl mx-auto px-4">
                <div className="flex justify-between items-center h-16 border-b border-gray-200">
                    <div className="flex items-center space-x-8">
                        <h1 className="font-bold text-2xl tracking-wider">SAMSUNG</h1>
                        <nav className="hidden md:flex items-center space-x-6 text-sm font-medium text-gray-700">
                            <a href="#" className="hover:text-black">オンラインショップ</a>
                            <a href="#" className="hover:text-black">製品情報</a>
                        </nav>
                    </div>
                    <div className="flex items-center space-x-6">
                        <div className="hidden md:flex items-center space-x-6 text-sm font-medium text-gray-700">
                            <a href="#" className="hover:text-black">サポート</a>
                            <a href="#" className="hover:text-black">法人のお客様</a>
                        </div>
                        <div className="flex items-center space-x-4">
                           <button aria-label="Search" className="text-gray-700 hover:text-black"><SearchIcon /></button>
                           <button aria-label="Cart" className="text-gray-700 hover:text-black"><CartIcon /></button>
                           <button aria-label="User" className="text-gray-700 hover:text-black"><UserIcon /></button>
                        </div>
                    </div>
                </div>
            </div>
            <div className={`transition-all duration-300 overflow-hidden ${isScrolled ? 'max-h-20' : 'max-h-0'}`}>
                <div className="max-w-screen-xl mx-auto px-4">
                    <div className="flex justify-between items-center h-16 border-b border-gray-200">
                        <div className="flex items-center space-x-2">
                           <h2 className="text-lg font-bold">Galaxy Z Fold7</h2>
                           <ChevronDownIcon />
                        </div>
                        <div className="flex items-center space-x-6">
                            <a href="#" className="text-sm font-medium text-gray-700 hover:text-black">レビュー</a>
                            <a href="#" className="bg-blue-600 text-white px-5 py-2 rounded-full text-sm font-bold hover:bg-blue-700 transition-colors">ご購入はこちら</a>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;
