import React from 'react';
import { PlusIcon } from './icons';

/**
 * 製品に関連するアクセサリーを紹介するセクション。
 * - 各アクセサリーの画像と名前をカード形式で表示します。
 */
const AccessoriesSection: React.FC = () => {
    const accessories = [
        { name: 'スリムSペンケース', image: 'https://picsum.photos/id/301/600/600' },
        { name: 'クリアガジェットケース', image: 'https://picsum.photos/id/302/600/600' },
    ];

    return (
        <section className="bg-gray-50 py-24">
            <div className="max-w-screen-xl mx-auto px-4 text-center">
                <h2 className="text-4xl md:text-6xl font-bold mb-12">Foldをスタイリッシュに保つアクセサリー</h2>
                <div className="grid md:grid-cols-2 gap-8">
                    {accessories.map((acc, index) => (
                        <div key={index} className="bg-gray-200 rounded-2xl p-4 relative group overflow-hidden">
                            <img src={acc.image} alt={acc.name} className="w-full h-auto rounded-lg object-cover group-hover:scale-105 transition-transform duration-500"/>
                            <div className="absolute bottom-6 left-6 text-left">
                                <h3 className="text-2xl font-bold text-black">{acc.name}</h3>
                            </div>
                            <button className="absolute top-6 right-6 bg-white/50 backdrop-blur-sm w-12 h-12 rounded-full flex items-center justify-center text-black hover:bg-white transition-colors">
                                <PlusIcon className="w-8 h-8"/>
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default AccessoriesSection;
