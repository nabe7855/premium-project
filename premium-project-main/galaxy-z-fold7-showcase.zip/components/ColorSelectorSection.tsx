import React, { useState } from 'react';

/**
 * 製品のカラーバリエーションを紹介し、選択できるセクション。
 * - ユーザーがカラーボタンをクリックすると、表示される製品名が変わります。
 * - 製品画像とカラー選択ボタン、購入ボタンで構成されます。
 */
const ColorSelectorSection: React.FC = () => {
    const colors = [
        { name: 'ブルーシャドウ', class: 'bg-blue-800' },
        { name: 'シルバー', class: 'bg-gray-300' },
        { name: 'ブラック', class: 'bg-black' },
        { name: 'グリーン', class: 'bg-green-700' },
    ];
    const [activeColor, setActiveColor] = useState(colors[0]);

    return (
        <section className="bg-white py-24 text-center">
            <div className="max-w-screen-xl mx-auto px-4">
                <h2 className="text-4xl md:text-6xl font-bold">洗練されたカラーに宿る先進技術</h2>
                <div className="my-12 h-96 flex items-center justify-center">
                     <img src="https://picsum.photos/id/202/400/800" alt="Galaxy Z Fold7 color options" className="h-full object-contain filter blur-sm hover:blur-none transition-all duration-500" />
                </div>
                <p className="text-2xl font-semibold">{activeColor.name}</p>
                <div className="flex justify-center items-center space-x-4 my-6">
                    {colors.map(color => (
                        <button key={color.name} onClick={() => setActiveColor(color)} className={`w-10 h-10 rounded-full transition-transform duration-300 ${color.class} ${activeColor.name === color.name ? 'ring-2 ring-offset-2 ring-blue-500 scale-110' : ''}`} aria-label={`Select color ${color.name}`}></button>
                    ))}
                </div>
                <button className="border border-black text-black px-8 py-3 rounded-full font-bold hover:bg-black hover:text-white transition-colors">
                    ご購入はこちら
                </button>
            </div>
        </section>
    );
};

export default ColorSelectorSection;
