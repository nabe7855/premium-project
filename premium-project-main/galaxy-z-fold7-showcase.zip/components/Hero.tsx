import React from 'react';

/**
 * ページのヒーローセクション（ファーストビュー）。
 * - 全画面の背景画像と製品名、キャッチコピーを表示します。
 * - 購入ボタンと製品レビューの星評価が特徴です。
 */
const Hero: React.FC = () => (
    <section className="relative h-screen bg-gray-50 flex items-center justify-center pt-16">
        <div className="absolute inset-0">
             <img src="https://picsum.photos/id/1/1920/1080" alt="Galaxy Z Fold7" className="w-full h-full object-cover"/>
             <div className="absolute inset-0 bg-gray-100 mix-blend-lighten"></div>
        </div>
        <div className="relative z-10 text-center text-gray-800">
            <h2 className="text-6xl md:text-8xl font-black tracking-tighter">Galaxy Z Fold7</h2>
            <p className="text-3xl md:text-5xl font-bold text-blue-600 mt-2">Galaxy AI ✨</p>
            <div className="mt-8 flex flex-col items-center">
              <button className="border border-gray-800 text-gray-800 px-8 py-3 rounded-full font-bold hover:bg-gray-800 hover:text-white transition-colors">
                  ご購入はこちら
              </button>
              <div className="mt-4 opacity-0 animate-[fadeIn_1s_ease-in-out_1s_forwards]">
                  <div className="flex items-center space-x-1">
                      {[...Array(5)].map((_, i) => <span key={i} className="text-yellow-400 text-2xl">★</span>)}
                  </div>
                  <p className="text-sm text-gray-600 mt-1">4.8 (953)</p>
              </div>
            </div>
        </div>
        <style>{`
            @keyframes fadeIn {
                to { opacity: 1; }
            }
        `}</style>
    </section>
);

export default Hero;
