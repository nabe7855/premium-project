
export interface Feature {
  title: string;
  subtitle: string;
  description: string;
  imageUrl: string;
}
