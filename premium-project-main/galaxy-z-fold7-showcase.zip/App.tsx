import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ScrollText from './components/ScrollText';
import FeatureShowcase from './components/FeatureShowcase';
import MediaReviews from './components/MediaReviews';
import ThinnessSection from './components/ThinnessSection';
import ColorSelectorSection from './components/ColorSelectorSection';
import AccessoriesSection from './components/AccessoriesSection';
import Footer from './components/Footer';

/**
 * アプリケーションのメインコンポーネント。
 * 各セクションのコンポーネントをインポートし、ページ全体のレイアウトを構成します。
 */
export default function App() {
  return (
    <main>
        <Header />
        <Hero />
        <ScrollText />
        <FeatureShowcase />
        <MediaReviews />
        <ThinnessSection />
        <ColorSelectorSection />
        <AccessoriesSection />
        <Footer />
    </main>
  )
}
